export class Costs {
    constructor (
    public id: number,
    public description: string,
    public cost: number,
    public category: string,
    public type: string

    ) {}
}